
function calculate() {
    //get info from form
    var gender = document.forms["bmr-form"]["gender"].value;
    var weight = document.forms["bmr-form"]["weight"].value;
    var height = document.forms["bmr-form"]["height"].value;
    var age = document.forms["bmr-form"]["age"].value;
    var activity = document.forms["bmr-form"]["activity"].value;

    //check form is filled
    if (document.forms["bmr-form"]["weight"].value.length == null || 
        document.forms["bmr-form"]["height"].value.length == null || 
        document.forms["bmr-form"]["gender"].value.length == null || 
        document.forms["bmr-form"]["age"].value.length == null || 
        document.forms["bmr-form"]["activity"].value.length == null) {
        alert("Please complete all details");
    }
    else if (gender == "female") {     //calc female BMR
        bmr = 655.1 + (9.6 * (weight)) + (1.8 * (height)) - (4.7 * (age));
    } 
    else {     //calc male BMR
        bmr = 66.47 + (13.7 * (weight)) + (5 * (height)) - (6.8 * (age));
    }
    //round BRM to whole value
    bmr = Math.round(bmr);
    //use BMR to calc calories needed
    var calories = (bmr * activity);
    //round to whole number
    calories = Math.round(calories);
    //return result
    resultBMR = "Your daily calorie requirement is " + calories + " calories."  
  
    document.forms["bmr-form"]["bmr"].value = calories + " calories";
  alert(resultBMR);
}

//reset form
function reset() {
    document.forms["bmr-form"].reset();
}

