
var baseUrl = "http://ssh.animeweedlord.com:1337/";
var loginUrl = baseUrl + "login";
var registerUrl = baseUrl + "register";


// Function that loads login info from any form on the page.
function loginFromForm() {
	var username = document.forms["login-form"]["username"].value;
    var password = document.forms["login-form"]["password"].value;

    var data = { "username" : username, "password" : password };
    disable();
	$.ajax({
	    type: "POST",
	    url: loginUrl,
	    processData: false,
	    contentType: 'application/json',
	    data: JSON.stringify(data),
	    success: function(u) {
	    	// Store useful information in web storage.
	    	// Have to do this for each element.
	    	localStorage.username = u.username;
	    	localStorage.firstName = u.firstname;
	    	localStorage.lastName = u.lastname;
	    	localStorage.email = u.email;
	    	localStorage.gender = u.gender;

	    	// Redirect to home page.
    	    document.location.href = "index.html";
    	    return true;
    	},
    	error:function (xhr, ajaxOptions, thrownError){
		    if(xhr.status == 404) {
		        // Username doesn't exist
		        alert("User does not exist");
		        enable();
		    }
		    else if (xhr.status == 401) {
		    	// Wrong pw
		    	alert("Incorrect Password");
		    	enable();
		    }
		    else {
		    	// Server error
		    	alert("Error code " + xhr.status);
		    	enable();
		    }
		    return false;
		}
	});

}

function disable() {
	//document.forms["login-form"]["username"].disabled = true;
    //document.forms["login-form"]["password"].disabled = true;
}

function enable() {
	//document.forms["login-form"]["username"].disabled = false;
    //document.forms["login-form"]["password"].disabled = false;
}

function register() {

	var password1 = document.getElementById('password');
	var password2 = document.getElementById('passwordverify');

	//Allows the user to register if the password is correct. 
	if(password1.value == password2.value){

		var username = document.forms["register-form"]["username"].value;
	    var password = document.forms["register-form"]["password"].value;
	    var email = document.forms["register-form"]["email"].value;
	    var firstName = document.forms["register-form"]["fname"].value;
	    var lastName = document.forms["register-form"]["lname"].value;
	    //var gender = document.forms["register-form"]["gender"].value;
	    var gender = getGender();
	    var data = { 
	    	"username" : username,
	    	"password" : password,
	    	"email" : email,
	    	"gender": gender,
	    	"firstname": firstName,
	    	"lastname": lastName,
	    };
	    

	    disable();
		$.ajax({
		    type: "POST",
		    url: registerUrl,
		    processData: false,
		    contentType: 'application/json',
		    data: JSON.stringify(data),
		    success: function(u) {
		    	// Store useful information in web storage.
		    	// Have to do this for each element.
		    	localStorage.username = username;
		    	localStorage.firstName = firstName;
		    	localStorage.lastName = lastName;
		    	localStorage.email = email;
		    	localStorage.gender = gender;

		    	// Redirect to home page.
	    	    document.location.href = "index.html";
	    	    return true;
	    	},
	    	error:function (xhr, ajaxOptions, thrownError){
			    if(xhr.status == 409) {
			        // Username already exists.
			        alert("Username taken.");
			        enable();
			    }
			    else {
			    	// Server error
			    	alert("Error code " + xhr.status);
			    	enable();
			    }
			    return false;
			}
		});
	}
	else {
		alert("Error: Passwords don't match.");
	}

}

function logout() {
	// Delete all local storage.
	localStorage.removeItem("username");
	localStorage.removeItem("password");
}

function logoutFromForm() {
	// Logs the user out.
	logout();
	document.location.href = "index.html";
}