// This file contains functions to update the DOM based on login status.
// Login status is stored in web-storage.
// Temporary web-storage based login check.
function isLoggedIn() {
	if(localStorage.username) {
		return localStorage.username
	}
	return false;
}

// Checks if logged in and sets the header content appropriately.
function doHeaderLogin() {
	var un = isLoggedIn();
	if(un) {
		$(".login-tab").html("<li>Hi, " + un + "!</li>");
		$(".signup").addClass("hide");
		$(".register").addClass("hide");
		$(".signup-content").addClass("hide");

		$("#welcome").append(un + "!");

		$("#regHam").addClass("hide");
		$("#logHam").addClass("hide");
	}
	else {
		$(".login-icon").html("<img src='img/icons/empty.png'>");
		$(".login-tab").attr('href', "login.html");
		$("#profHam").addClass("hide");
		$("#welcome").addClass("hide");
	}
}

$( document ).ready(function() {
	// Set the header to the users name.
	doHeaderLogin();

	// TODO: Find a better spot for these.
	// Attatch FastClick to remove delay on mobile tap
	FastClick.attach(document.body);

	// Make the header recede on scroll down.
	// Grab an element
	var myElement = document.querySelector("header");
	// Construct an instance of Headroom, passing the element
	var headroom  = new Headroom(myElement);
	headroom.init(); 
});