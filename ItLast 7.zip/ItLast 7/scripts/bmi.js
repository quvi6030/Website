function calcBMI(weight, height) {
	return weight / (height/100 * height/100);
}


function calculate() {
    var weight = document.forms["bmi-form"]["weight"].value;
    var height = document.forms["bmi-form"]["height"].value;
    var yourBmi = calcBMI(weight, height).toFixed(2);
}

function reset() {
    document.forms["bmi-form"].reset();
}

//Vi's part (I have changed everything to JQUERY ;P  ) 
$(document).ready(function() {
    $('#case1').hide();
    $('#case2').hide();
    $('#case3').hide();
    $('#case4').hide();
    var updating = false;
    $("#height, #weight").on("input", function(){
        if(!updating) {
            updating = true;
            var $height = parseFloat($('input[name=height]').val());
            var $weight = parseFloat($('input[name=weight]').val());
            var result = calcBMI($weight, $height).toFixed(1);
            document.forms["bmi-form"]["bmi"].value = result;
            
            if (result < 20){
                $('#case1').fadeIn(100);
            }
            else{
                $('#case1').hide();
            }

            if (result >= 20 && result < 25){
                $('#case2').fadeIn(100);
            }
            else{
                $('#case2').hide();
            }

            if (result >= 25 && result < 33){
                $('#case3').fadeIn(100);
            }
            else{
                $('#case3').hide();
            }

            if (result >=33){
                $('#case4').fadeIn(100);
            }
            else{
                $('#case4').hide();
            }
            updating = false;
        }
    });
});