$( document ).ready(function() {
  $( '#hamburger-logo' ).click(function(){
		$('.responsive-menu').toggleClass('expand')
	})
});