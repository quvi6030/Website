var theGender = "m";

function validatepw()  {                  
  var password1 = document.getElementById('password');
  var password2 = document.getElementById('passwordverify');
  var message = document.getElementById('confirm');
  var match = "#44EE99";
  var mistake = "#EE4444";

  if(password.value == passwordverify.value){
    passwordverify.style.backgroundColor = match;
    message.style.color = match;
  } else {
    passwordverify.style.backgroundColor = mistake;
    message.style.color = mistake;
  }
}  

function reset() {
    var male = document.getElementById('male');
    var female = document.getElementById('female');
    document.forms["register-form"].reset();
    passwordverify.style.backgroundColor = "";
    male.style.backgroundColor = "";
    female.style.backgroundColor = "";
}

function male() {
  var male = document.getElementById('male');
  var female = document.getElementById('female');
  male.style.backgroundColor = "#44EE99";
  female.style.backgroundColor = "#9C9C9C";
  theGender="m";
}

function female() {
  var female = document.getElementById('female');
  var male = document.getElementById('male');
  female.style.backgroundColor = "#44EE99";
  male.style.backgroundColor = "#9C9C9C";
  theGender="f";
}

function getGender() {
  return theGender;
}